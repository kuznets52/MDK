﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PR12_Lebedev
{
    public partial class ViewApplicantsForm: Form
    {
        public ViewApplicantsForm()
        {
            InitializeComponent();
            LoadApplicantsData();
        }
        private void LoadApplicantsData()
        {
            try
            {
                string connectionString = "host=10.207.106.12;uid=user41;pwd=tp10;database=db41";
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT * FROM applicants ORDER BY applicant_id";
                    MySqlCommand command = new MySqlCommand(query, connection);

                    MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dataGridViewApplicants.DataSource = dataTable;

                    if (dataGridViewApplicants.Columns.Count > 0)
                    {
                        dataGridViewApplicants.Columns["applicant_id"].Visible = false;
                        dataGridViewApplicants.Columns["full_name"].HeaderText = "ФИО";
                        dataGridViewApplicants.Columns["birth_date"].HeaderText = "Дата рождения";
                        dataGridViewApplicants.Columns["passport_number"].HeaderText = "Паспорт";
                        dataGridViewApplicants.Columns["average_score"].HeaderText = "Средний балл";
                        dataGridViewApplicants.Columns["specialty"].HeaderText = "Специальность";
                        dataGridViewApplicants.Columns["phone"].HeaderText = "Телефон";
                    }

                    lblStatus.Text = $"Найдено абитуриентов: {dataTable.Rows.Count}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка");
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadApplicantsData();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
