﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PR12_Lebedev
{
    public partial class DeleteApplicantsForm: Form
    {
        private DataTable dataTable;
        
        public DeleteApplicantsForm()
        {
            InitializeComponent();
            LoadApplicantsData();
        }
        private void LoadApplicantsData()
        {
            try
            {
                string connectionString = "host=10.207.106.12;uid=user41;pwd=tp10;database=db41";
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT * FROM applicants ORDER BY applicant_id";
                    MySqlCommand command = new MySqlCommand(query, connection);

                    MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                    dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dataGridViewApplicants.DataSource = dataTable;

                    if (dataGridViewApplicants.Columns.Count > 0)
                    {
                        dataGridViewApplicants.Columns["applicant_id"].Visible=false;
                        dataGridViewApplicants.Columns["full_name"].HeaderText = "ФИО";
                        dataGridViewApplicants.Columns["birth_date"].HeaderText = "Дата рождения";
                        dataGridViewApplicants.Columns["passport_number"].HeaderText = "Паспорт";
                        dataGridViewApplicants.Columns["average_score"].HeaderText = "Средний балл";
                        dataGridViewApplicants.Columns["specialty"].HeaderText = "Специальность";
                        dataGridViewApplicants.Columns["phone"].HeaderText = "Телефон";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewApplicants.CurrentRow == null)
            {
                MessageBox.Show("Выберите абитуриента для удаления", "Информация");
                return;
            }

            DataGridViewRow row = dataGridViewApplicants.CurrentRow;
            string applicantName = row.Cells["full_name"].Value?.ToString();
            string specialty = row.Cells["specialty"].Value?.ToString();

            if (MessageBox.Show($"Удалить абитуриента:\n{applicantName}\nСпециальность: {specialty}?",
                "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string connectionString = "host=10.207.106.12;uid=user41;pwd=tp10;database=db41";

                    using (MySqlConnection connection = new MySqlConnection(connectionString))
                    {
                        connection.Open();

                        int applicantId = Convert.ToInt32(row.Cells["applicant_id"].Value);
                        string deleteQuery = "DELETE FROM applicants WHERE applicant_id = @applicantId";

                        MySqlCommand command = new MySqlCommand(deleteQuery, connection);
                        command.Parameters.AddWithValue("@applicantId", applicantId);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Абитуриент успешно удален!", "Успех",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadApplicantsData();
                        }
                        else
                        {
                            MessageBox.Show("Не удалось удалить абитуриента", "Ошибка",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show($"Ошибка базы данных: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadApplicantsData();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridViewApplicants_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridViewApplicants.Rows[e.RowIndex].Cells["applicant_id"].Value != null)
            {
                DataGridViewRow row = dataGridViewApplicants.Rows[e.RowIndex];
                DisplayApplicantInfo(row);
            }
        }

        private void DisplayApplicantInfo(DataGridViewRow row)
        {
            lblSelectedInfo.Text = $"Выбран: {row.Cells["full_name"].Value}\n" +
                                 $"Паспорт: {row.Cells["passport_number"].Value}\n" +
                                 $"Специальность: {row.Cells["specialty"].Value}";
        }
    }
}
