﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR12_Lebedev_2
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        private void btnViewApplicants_Click(object sender, EventArgs e)
        {
            try
            {
                ViewApplicantsForm viewForm = new ViewApplicantsForm();
                viewForm.FormClosed += (s, args) => btnViewApplicants.Enabled = true;
                viewForm.Show();
                btnViewApplicants.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
                btnViewApplicants.Enabled = true;
            }
        }

        private void btnDeleteApplicants_Click(object sender, EventArgs e)
        {
            try
            {
                DeleteApplicantsForm deleteForm = new DeleteApplicantsForm();
                deleteForm.FormClosed += (s, args) => btnDeleteApplicants.Enabled = true;
                deleteForm.Show();
                btnDeleteApplicants.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка");
                btnDeleteApplicants.Enabled = true;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
