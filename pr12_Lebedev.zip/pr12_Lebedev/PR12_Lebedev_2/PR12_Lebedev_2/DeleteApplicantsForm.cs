﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PR12_Lebedev_2
{
    public partial class DeleteApplicantsForm : Form
    {
        public DeleteApplicantsForm()
        {
            InitializeComponent();
            btnDelete.Enabled = false;
            FillDataGrid();
        }

        void FillDataGrid()
        {
            string strCon = "host=localhost;uid=root;pwd=root;database=db41";
            string strCmd = "SELECT * FROM applicants ORDER BY applicant_id";

            using (MySqlConnection con = new MySqlConnection(strCon))
            {
                try
                {
                    con.Open();

                    MySqlDataAdapter da = new MySqlDataAdapter(strCmd, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Отключаем автоматическое выделение перед установкой DataSource
                    dataGridViewApplicants.DataSource = null;
                    dataGridViewApplicants.DataSource = dt;

                    // Настройка отображения столбцов
                    if (dataGridViewApplicants.Columns.Count > 0)
                    {
                        dataGridViewApplicants.Columns["applicant_id"].Visible = false;
                        dataGridViewApplicants.Columns["full_name"].HeaderText = "ФИО";
                        dataGridViewApplicants.Columns["birth_date"].HeaderText = "Дата рождения";
                        dataGridViewApplicants.Columns["passport_number"].HeaderText = "Паспорт";
                        dataGridViewApplicants.Columns["average_score"].HeaderText = "Средний балл";
                        dataGridViewApplicants.Columns["specialty"].HeaderText = "Специальность";
                        dataGridViewApplicants.Columns["phone"].HeaderText = "Телефон";
                    }

                    // Явно сбрасываем выделение
                    dataGridViewApplicants.ClearSelection();
                    dataGridViewApplicants.CurrentCell = null;

                    btnDelete.Enabled = false;
                    lblSelectedInfo.Text = "Выберите абитуриента из списка";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dataGridViewApplicants_SelectionChanged(object sender, EventArgs e)
        {
            // Проверяем, что выделение произошло именно пользователем, а не автоматически
            if (dataGridViewApplicants.Focused &&
                dataGridViewApplicants.CurrentRow != null &&
                dataGridViewApplicants.CurrentRow.Index >= 0 &&
                dataGridViewApplicants.CurrentRow.Cells["applicant_id"].Value != null)
            {
                DataGridViewRow row = dataGridViewApplicants.CurrentRow;

                string fullName = row.Cells["full_name"].Value?.ToString() ?? "";
                string passport = row.Cells["passport_number"].Value?.ToString() ?? "";
                string specialty = row.Cells["specialty"].Value?.ToString() ?? "";

                lblSelectedInfo.Text = $"Выбран: {fullName}\nПаспорт: {passport}\nСпециальность: {specialty}";
                btnDelete.Enabled = true;
            }
            else
            {
                btnDelete.Enabled = false;
                lblSelectedInfo.Text = "Выберите абитуриента из списка";
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewApplicants.CurrentRow == null ||
                dataGridViewApplicants.CurrentRow.Cells["applicant_id"].Value == null)
            {
                MessageBox.Show("Выберите абитуриента для удаления", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DataGridViewRow row = dataGridViewApplicants.CurrentRow;
            int applicantId = Convert.ToInt32(row.Cells["applicant_id"].Value);
            string fullName = row.Cells["full_name"].Value?.ToString() ?? "";
            string specialty = row.Cells["specialty"].Value?.ToString() ?? "";

            string strCon = "host=localhost;uid=root;pwd=root;database=db41";

            using (MySqlConnection con = new MySqlConnection(strCon))
            {
                try
                {
                    con.Open();

                    string strCmd = "DELETE FROM applicants WHERE applicant_id = @applicantId";
                    MySqlCommand cmd = new MySqlCommand(strCmd, con);
                    cmd.Parameters.AddWithValue("@applicantId", applicantId);

                    DialogResult dr = MessageBox.Show(
                        $"Удалить абитуриента:\n{fullName}\nСпециальность: {specialty}?",
                        "Подтверждение удаления",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);

                    if (dr == DialogResult.Yes)
                    {
                        int res = cmd.ExecuteNonQuery();

                        if (res > 0)
                        {
                            MessageBox.Show("Абитуриент успешно удален!", "Успех",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                            FillDataGrid();
                        }
                        else
                        {
                            MessageBox.Show("Не удалось удалить абитуриента", "Ошибка",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show($"Ошибка базы данных: {ex.Message}\nКод ошибки: {ex.Number}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            FillDataGrid();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Добавляем обработчик события загрузки данных
        private void dataGridViewApplicants_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            // Гарантированно сбрасываем выделение после загрузки данных
            dataGridViewApplicants.ClearSelection();
            dataGridViewApplicants.CurrentCell = null;
            btnDelete.Enabled = false;
            lblSelectedInfo.Text = "Выберите абитуриента из списка";
        }
    }
}
